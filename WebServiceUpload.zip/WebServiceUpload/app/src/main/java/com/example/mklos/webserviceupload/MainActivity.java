package com.example.mklos.webserviceupload;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
public class MainActivity extends AppCompatActivity {
    static final int REQUEST_IMAGE_CAPTURE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Activated when button is pushed; checks for camera permissions and requests them if applicable. Opens camera.
     * @param view
     */
    public void dispatchTakePictureIntent(View view) {
        System.out.println("Function");
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CAMERA}, REQUEST_IMAGE_CAPTURE);
        }
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            System.out.println("Function");
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            System.out.println("Function");
        } else {
            dispatchTakePictureIntent(view);
        }
    }
    /**
     * Returns photo from Camera activity. Calls methods to create RequestBody and Request for web call and calls the Send method.
     * @param requestCode
     * @param resultCode
     * @param data
     */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        final TextView text = (TextView) findViewById(R.id.text);
        ImageView image = (ImageView) findViewById(R.id.Preview);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            image.setImageBitmap(photo);
            File PhotoFile = getFile(photo);
            Request request = createRequest(createRequestBody(PhotoFile));
            sendFile(request);

        }
    }
    /**
     * Takes the raw bitmap from the Camera and creates a File object containing the photo converted to a JPEG.
     * @param bitmap
     * @return JPEG file to be sent
     */
    private File getFile(Bitmap bitmap) {
        File file = new File(getApplicationContext().getCacheDir(), "photo.jpg");
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.close();
        } catch (FileNotFoundException e) {
            e.getMessage();
        } catch (IOException e) {
            e.getMessage();
        }
        return file;
    }
    /**
     * Creates the RequestBody for the web call.
     * @param photo
     * @return Request Body for web call
     */
    private RequestBody createRequestBody(File photo) {
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("name", "photo")
                .addFormDataPart("photo", photo.getName(),
                        RequestBody.create(MediaType.parse("image/jpeg"), photo))
                .build();
        return requestBody;
    }
    /**
     * Creates the Request for the web call.
     * @param body
     * @return Request for web call
     */
    private Request createRequest(RequestBody body) {
        Request request = new Request.Builder()
                .url("http://winksplayground.x10host.com/imageservice")
                .method("POST", RequestBody.create(null, new byte[0]))
                .post(body)
                .build();
        return request;
    }
    /**
     * Sends file to server, listens for response and displays response on screen.
     * @param request
     */
    private void sendFile(Request request){
        final TextView text = (TextView) findViewById(R.id.text);
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, final IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        text.setText(e.getMessage());
                    }
                });
            }
            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            text.setText(response.body().string());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
    }
}